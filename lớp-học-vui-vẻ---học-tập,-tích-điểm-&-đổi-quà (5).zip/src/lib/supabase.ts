import { createClient } from '@supabase/supabase-js';

export const SUPABASE_URL: string =
  (import.meta as any).env?.VITE_SUPABASE_URL || 'https://iqngiwjgkwsiuclxudox.supabase.co';

export const SUPABASE_ANON_KEY: string =
  (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_publishable_Bt0oR1QjbyvOkjSEg_aBTg_kJYEhfeQ';

export interface SupabaseLink {
  id?: string | number;
  title: string;
  url: string;
  description?: string;
  category?: string;
  created_at?: string;
  icon?: string;
  target?: string;
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export default supabase;
